import React, {useState} from "react";
import {Routes, Route } from 'react-router-dom';
import DashBoardPage from "./DashBoardPage";
import Employees from "./Employees";
import EmployeeDetails from './EmployeeDetails'
import About from "./About";

export default function BodySection() {
    const employeeList = [
        {
          name: "Emp 1",
          empId: "1000",
          department: '',
          skillSet: '',
          image: ''
        },
        {
          name: "Emp 2",
          empId: "1001",
        },
        {
          name: "Emp 3",
          empId: "1002",
        },
      ];

    const getItemById = (id) => {
        return employeeList.find(emp => emp.empId === id);
    };

  return (
    <div id="content-wrapper" className="d-flex flex-column">
      <div id="content">
        <div className="container-fluid">
          <div className="d-sm-flex align-items-center justify-content-between mb-4">
              <Routes>
                <Route index path="/dashboard" element={<DashBoardPage />}></Route>
                <Route index element={<DashBoardPage />}></Route>
                <Route path="/employees" element={<Employees employees={employeeList} />}></Route>
                <Route path="/employees/:empid" element={<EmployeeDetails getItem={getItemById} />}></Route>
                <Route path="/about" element={<About />}></Route>
              </Routes>
          </div>
        </div>
      </div>
    </div>
  );
}
