import React from "react";
import Sidebar from "./Sidebar";
import BodySection from "./BodySection";

export default function AdminDashboard() {
  return (
    <div id="wrapper">
      <Sidebar />
      <BodySection></BodySection>
    </div>
  );
}
