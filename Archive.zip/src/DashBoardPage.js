import React from 'react'

export default function DashBoardPage() {
  return (
    <div>DashBoardPage Chnage</div>
  )
}
