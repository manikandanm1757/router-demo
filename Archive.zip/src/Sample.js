import react, { Component } from "react";

class Sample extends react.Component {
  render() {
    return <p> Sample Class Component !! {this.props.name}</p>;
  }
}

export default Sample;
