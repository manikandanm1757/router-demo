import React from "react";
import { useParams } from "react-router-dom";

export default function EmployeeDetails({ getItem }) {
  const { empid } = useParams();
  const empDetails = getItem(empid);
  return (
    <div>
      {empDetails ? (
        <div>
          <h3>Employee Details</h3>
          <p>Name: {empDetails.name}</p>
          <p>Id: {empDetails.empId}</p>
        </div>
      ) : (
        <p>Employee Not Found!!</p>
      )}
    </div>
  );
}
