import React, { useState } from "react";
import { Link } from "react-router-dom";

export default function Employees({ employees }) {
  return (
    <ul className="list-group">
      {employees.map((emp) => {
        return (
          <Link key={emp.empId} to={`/employees/${emp.empId}`}>
            <li className="list-group-item">
              {emp.name}({emp.empId})
            </li>
          </Link>
        );
      })}
    </ul>
  );
}
